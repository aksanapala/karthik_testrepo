#!/usr/bin/python
import MySQLdb as mdb
con = mdb.connect('localhost','user50','user50','batch50')
cur = con.cursor()
cur.execute("create table students(name varchar(10),gender varchar(6))")
con.close()

'''
mysql> show tables;
+-------------------+
| Tables_in_batch49 |
+-------------------+
| students          |
+-------------------+
1 row in set (0.00 sec)

mysql> desc students;
+--------+-------------+------+-----+---------+-------+
| Field  | Type        | Null | Key | Default | Extra |
+--------+-------------+------+-----+---------+-------+
| name   | varchar(10) | YES  |     | NULL    |       |
| gender | varchar(6)  | YES  |     | NULL    |       |
+--------+-------------+------+-----+---------+-------+
2 rows in set (0.00 sec)
'''
