#!/usr/bin/python
import MySQLdb as mdb

name = raw_input("please enter your name:")
gender = raw_input("please enter your gender:")
con = mdb.connect('localhost','user50','user50','batch50')
cur = con.cursor()
cur.executemany("insert into students (name,gender) values (%s,%s)",[(name,gender)])
con.commit()
con.close()
