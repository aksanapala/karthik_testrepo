#!/usr/bin/python
import MySQLdb as mdb
con = mdb.connect('localhost','user50','user50','batch50')
cur = con.cursor()
cur.execute("select version()")
output = cur.fetchone()[0]
print output
con.close()
