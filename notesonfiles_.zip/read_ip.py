#!/usr/bin/python

import re
f = open("ipconfig.txt","r")
ip_out = f.read()
f.close()

print re.search('.*:([0-9.]+).*bcast',ip_out,re.I).group(1)




