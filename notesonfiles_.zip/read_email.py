#!/usr/bin/python
import re

reg1 = re.compile('[0-9a-z.]+@[a-z.]+')
f = open('email_id.txt','r')
email_output = f.read()
f.close()

print reg1.findall(email_output)


