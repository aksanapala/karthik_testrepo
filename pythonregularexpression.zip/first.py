#!/usr/bin/python
import re

answer = raw_input("do you want to the movies? - yes/no :")
#if answer == 'yes' or answer == 'y':
if re.match(answer,'yes',re.I):
  print "you are welcome to come"
else:
  print "ok better luck next time"
  

