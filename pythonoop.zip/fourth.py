#!/usr/bin/python
# 

class Account:
  def __init__(self):   # constructor
    self.balance = 0
  def deposit(self,amount):
    self.balance = self.balance + amount
  def withdraw(self,amount):
    self.balance = self.balance - amount
  def display(self):
    return "my balance is {}".format(self.balance)

if __name__ == '__main__':   
  hari = Account()
  print "depositing 1000 for hari"
  hari.deposit(1000)
  print "balance for hari after deposit"
  print hari.display()
  print "withdraw 100 for hari"
  hari.withdraw(100)
  print "balance for hari after withdraw"
  print hari.display()

