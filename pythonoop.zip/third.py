#!/usr/bin/python

class Account:
  balance = 0
  def display(self):
    return "my balance is {}".format(self.balance)
    
kumar = Account()
print dir(kumar)
print kumar.balance
print kumar.display()
kumar.balance = 1000
print kumar.display()

vicky = Account()
print dir(vicky)
print vicky.balance
print vicky.display()

hari = Account
print dir(hari)
print hari.balance
print hari.display()

'''
print Account         #  __main__.Account
print type(Account)   #  <type 'classobj'>/class - car
print Account()       #  <__main__.Account instance at 0x7feb3942f5f0>
print type(Account()) #  <type 'instance'>/object - maruti

In [4]: my_string="python"

In [5]: my_string.
my_string.capitalize  my_string.isalnum     my_string.lstrip      my_string.splitlines
my_string.center      my_string.isalpha     my_string.partition   my_string.startswith
my_string.count       my_string.isdigit     my_string.replace     my_string.strip
my_string.decode      my_string.islower     my_string.rfind       my_string.swapcase
my_string.encode      my_string.isspace     my_string.rindex      my_string.title
my_string.endswith    my_string.istitle     my_string.rjust       my_string.translate
my_string.expandtabs  my_string.isupper     my_string.rpartition  my_string.upper
my_string.find        my_string.join        my_string.rsplit      my_string.zfill
my_string.format      my_string.ljust       my_string.rstrip      
my_string.index       my_string.lower       my_string.split       

In [5]: my_string.upper?
Type:       builtin_function_or_method
String Form:<built-in method upper of str object at 0x7f166c0ecfc0>
Docstring:
S.upper() -> string

Return a copy of the string S converted to uppercase.

In [6]: # my_string is an instance of str class


'''
