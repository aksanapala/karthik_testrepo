#!/usr/bin/python

def account():
  return {'balance':0}

def withdraw(account):
  account['balance'] = account['balance'] - 100
  return account['balance']

def deposit(account):
  account['balance'] = account['balance'] + 1000
  return account['balance']
  
# Main
kumar = account() # kumar['balance']=0
vicky = account() # vicky['balance']=0
deposit(kumar)
print "balance of kumar is {}".format(kumar['balance'])
withdraw(kumar)
print "balance of kumar is {}".format(kumar['balance'])
print "balance of vicky is {}".format(vicky['balance'])
