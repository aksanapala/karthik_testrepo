#!/usr/bin/python
# 

class Account:
  def __init__(self):   # constructor
    self.balance = 0
  def deposit(self,amount):
    self.balance = self.balance + amount
  def withdraw(self,amount):
    self.balance = self.balance - amount
  def display(self):
    return "my balance is {}".format(self.balance)
    
class MinBalAcc(Account):
  def __init__(self):
    Account.__init__(self)
  def withdraw(self,amount):
    if self.balance - amount < 1000:
      print "sorry you are hitting below the mim amount"
    else:
      Account.withdraw(self,amount)
      
# Main

# vinay  - employee
vinay = Account()
vinay.deposit(10000)
print "balance of vinay after depositing 10000 - {}".format(vinay.balance)
vinay.withdraw(9900)
print "balance of vinay after withdraw 9900 - {}".format(vinay.balance)

# venkat - student
venkat = MinBalAcc()
venkat.deposit(10000) # 9000 is actual balance 1000 is mim balance requirement.
print "balance of venkat after depositing 10000 - {}".format(venkat.balance)
venkat.withdraw(9000)
print "balance of venkat after withdraw 9000 - {}".format(venkat.balance)
venkat.withdraw(300)

