#!/usr/bin/python
# movie - A
# Exception is a parent class
# InvalidAge is a child class


class InvalidAge(Exception):
  def __init__(self,age):
    self.age  = age

  
def validate_age(age):
  if age >= 18:
    return "Enjoy the movies"
  else:
    raise InvalidAge(age)
    
# Main
age = int(raw_input("please enter the age:"))

try:
  validate_age(age)
except InvalidAge as e:
  print "buddy!!! you still need to grow {}".format(e.age)
else:
  print validate_age(age)
  
  


