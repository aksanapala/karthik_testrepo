#!/usr/bin/python
balance = 0

def withdraw():
  global balance
  balance = balance - 100
  return balance

def deposit():
  global balance
  balance = balance + 1000
  return balance  
  
#kumar
print "balance of kumar now {}".format(balance)
deposit()
print "deposit for kumar now{}".format(balance)
withdraw()
print "withdraw for kumar now{}".format(balance)
#vicky
print "balance of vicky now {}".format(balance) 
