#!/usr/bin/python
# welcome to the market
# pass
# logical operator - and/or

print "welcome to the market"
food_type = raw_input("please enter the food type:meat/fish/veg/chicken:")

if food_type == 'meat':
  pass
elif food_type == 'fish':
  print "welcome to the fish market"
  fish_type = raw_input("please enter your fish type - pomplet/solomon/tuna/rohu/fillets :")
  if fish_type == 'rohu':
    print "your {} is available".format(fish_type)
    print "how much quantity of {} you need".format(fish_type)
  elif fish_type == 'solomon':
    print "your {} is available".format(fish_type)
    print "how much quantity of {} you need".format(fish_type)
  elif fish_type == 'tuna' or fish_type == 'TUNA':
    print "your {} is available".format(fish_type)
    print "how much quantity of {} you need".format(fish_type)
  else:
    print "your {} is not available".format(fish_type)
    print "how about meat/chicken/veg".format(fish_type)  
elif food_type == 'veg':
  pass
elif food_type == 'chicken':
  pass
