#!/usr/bin/python
# welcome to the market

print "welcome to the market"
food_type = raw_input("please enter the food type:meat/fish/veg/chicken:")

if food_type == 'meat':
  pass
elif food_type == 'fish':
  pass
elif food_type == 'veg':
  pass
elif food_type == 'chicken':
  pass
