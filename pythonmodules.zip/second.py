#!/usr/bin/python

import sys
sys.path.insert(0,'/home/tcloudost/python-examples/batch-50/modules/extra')

import first

def my_add(a,b):
  '''
    this is for addition of two integers
  '''
  a = int(a)
  b = int(b)
  return a + b
  
# Main
print "addition of two numbers is {}".format(my_add(1,2))
print "addition of two string is {}".format(first.my_add("Modules"," day"))
