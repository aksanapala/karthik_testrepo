#!/usr/bin/python

version = 2.0

def my_add(a,b):
  ''' This is for addtion of string and numbers
      syntax: ex: my_add(1,2) or my_add("linux"," rocks")
  '''
  return a + b
  
def my_sub(a,b):
  """
  this is for subrstraction of two numbers
  """
  if a > b:
    return a - b
  else:
    return b - a
    
def my_multi(a,b):
  return a * b

# Main
# '__name__': '__main__'
if __name__ == '__main__':
  print "Launching a Missile"
  
  

  
  
