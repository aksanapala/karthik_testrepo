#!/usr/bin/python
# https://pymotw.com/2/getopt/
import sys
if len(sys.argv) != 3:
  print "./{} <arg1> <arg2>".format(sys.argv[0])
  sys.exit()
else:
  value1,value2 = sys.argv[1:]
  print int(value1) + int(value2)
