#!/usr/bin/python
def my_div(a,b):
  return a/b
my_div(10,0)
