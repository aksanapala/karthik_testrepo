#!/usr/bin/python
# fucntion witin function
# function enclosures

def outer():
  x = 1
  def inner():
    return x
  return inner  # label or the address of the inner function.
  
foo = outer() # 1
print globals()
print foo
print type(foo)
print foo()
#print inner()


'''
# example 1
def outer():
  x = 1
  def inner():
    return x
  return inner()
  
print outer() # 1
print inner()
'''
  
