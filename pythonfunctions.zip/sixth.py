#!/usr/bin/python
# **kwargs

def callme(**kwargs):
  if 'name' in kwargs:
    print "my name is {}".format(kwargs['name'])
  if 'gender' in kwargs:
    print "my gener is {}".format(kwargs['gender'])
  if 'maiden' in kwargs:
    print "my mothers maiden name is {}".format(kwargs['maiden'])
  if 'location' in kwargs:
    print "my location is {}".format(kwargs['location'])
  
  
callme(name="kumar",gender="m")
callme(maiden="vijaya",location="hyd")
callme(name="kumar",maiden="vijaya",location="hyd")
