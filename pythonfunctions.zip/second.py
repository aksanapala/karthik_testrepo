#!/usr/bin/python
# scope of a function.

balance=0

def deposit():
  global balance
  print locals()
  balance = balance + 1000
  return balance
  
def withdraw():
  global balance
  print locals()
  balance = balance - 300
  return balance

print globals()
print deposit()
print globals()
print withdraw()

'''
# example 2

a = 10

def my_func():
  print locals()
  return a


  
print my_func()
print globals()
print a




# example 1
a = 10

def my_func():
  a = 1
  print locals()
  return a


  
print my_func()
print globals()
print a
'''

# variables inside a function or outside a function a called namespaces.
# variables inside a function are called local namespaces.
# - Local variables are available during the runtime of the function.
# - Lifespan of the variable is during the runtime of the function.
# variables outside a function are called global namespaces.
# globals() will provide you the global name space.
# locals() will provide you the local name space.
# Inside a function - local variable is given higher precedence than global variable.
# scope resolution - If there is no variable locally, look into the global namespace.
# global keyword.
