#!/usr/bin/python
# *,**,*args,**kwargs

#*

def my_func(a,b):
  return a,b
  
# two arguments
# list of arguments
my_value=[1,2]
'''
a = my_value[0]
b = my_value[1]

# unpacking
a,b  = my_value
'''
print my_func(*my_value)


# **

my_value = {'a':1,'b':2,}
print my_func(**my_value)


