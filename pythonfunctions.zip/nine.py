#!/usr/bin/python
# decorate
#  http://simeonfranklin.com/blog/2012/jul/1/python-decorators-in-12-steps/

def outer(func):
  def inner(*args,**kwargs):
    value = func(*args,**kwargs)
    if value % 2 == 0:
      return "{} is a even number".format(value)
    else:
      return "{} is a odd number".format(value)
  return inner

'''
my_new = outer(max)
print my_new
my_new(22,33,44,55)
my_new(100,88,77,66)
'''

@outer
def gmax(*args):
  big=0
  for value in args:
    if big < value:
      big=value
  return big
  
'''
my_new = outer(gmax)
print my_new
'''
  
print gmax(22,33,44,55)
print gmax(a=100,b=88,c=77,d=66)

