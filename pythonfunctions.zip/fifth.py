#!/usr/bin/python
# *args
'''
In [1]: max?
Type:       builtin_function_or_method
String Form:<built-in function max>
Namespace:  Python builtin
Docstring:
max(iterable[, key=func]) -> value
max(a, b, c, ...[, key=func]) -> value

With a single iterable argument, return its largest item.
With two or more arguments, return the largest argument.

In [2]: max(-5,-1)
Out[2]: -1

In [3]: max(24,32,5,1,67,99)
Out[3]: 99


def gmax(*args):
  return args,type(args)
  
  
print gmax(1,2,3,4,5,6)
'''

def gmax(*args):
  big=0
  for value in args:
    if big < value:
      big=value
  return big
    
print gmax(1,2,3,4,5,6) 
print gmax(24,32,5,1,67,99)  
   
