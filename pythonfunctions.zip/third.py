#!/usr/bin/python
# functional arguments

def my_add(a,b):
  print locals()
  a = a + 10
  return a
'''
a = 10
b = 20 
# positional functional arguemtns
print my_add(a,b)
# Function arguments passed as dictionaries.
print my_add(b=20,a=10)
# default
'''

def my_multi(num,default=10):
  for value in range(1,default+1):
    print "{0:2d} * {1:2d} = {2:3d}".format(num,value,num*value)
    
my_multi(num=2,default=15)

# def putty(servername,port=22)
# putty(servername)
# putty(servername,port=23)
