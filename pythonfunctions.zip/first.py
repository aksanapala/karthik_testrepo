#!/usr/bin/python


def my_func():
  return "hello world"
  print "hey i am doing good"
  print "will you join today"
  
print type(my_func) # <type 'function'>
print my_func       # <function my_func at 0x7f9e089155f0> # label of the function.
print my_func()     # Hello world, None.

# every function will give you a return value.
# when no return value - None.
# return is not a print statement. It marks the end of the function.

