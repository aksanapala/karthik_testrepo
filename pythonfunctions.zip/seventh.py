#!/usr/bin/python
# functions are first class objects.

def my_add(a,b):
  return a + b
  
def my_sub(a,b):
  if a >  b:
    return a - b
  else:
    return b - a
    
def extra(func,x,y):
  return func(x,y)
  
print extra(my_add,10,2)

