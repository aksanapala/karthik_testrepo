#!/usr/bin/python
# logging.basicConfig?
import logging

# basic logging
logging.basicConfig(filename="myapp.log",filemode='a',level=logging.DEBUG,format='%(asctime)s - %(levelname)s - %(name)s - %(message)s',datefmt='%c')

logging.debug("hey this is a debug message")
logging.info("hey this is an information message")
logging.warning("hey this is a warning message")
logging.error("hey this is error message")
logging.critical("hey this is critical message")
