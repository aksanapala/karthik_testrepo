#!/usr/bin/python
# logging.basicConfig?
# logging.Formatter?
# man date
import logging

# basic logging
logging.basicConfig(filename="mydisk.log",filemode='a',level=logging.DEBUG,format='%(asctime)s - %(levelname)s - %(name)s - %(message)s',datefmt='%c')

# Main program
disk_size = int(raw_input("please enter the disk size:"))

if disk_size < 70:
  logging.info("The disk looks healthy at {}".format(disk_size))
elif disk_size < 75:
  logging.warning("The disk is getting filled up fast {}".format(disk_size))
elif disk_size < 85:
  logging.error("The disk is puking errors at {}".format(disk_size))
elif disk_size < 100:
  logging.critical("your application is sleeping now {}".format(disk_size))
