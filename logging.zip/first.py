#!/usr/bin/python
import logging
logging.debug("hey this is a debug message")
logging.info("hey this is an information message")
logging.warning("hey this is a warning message")
logging.error("hey this is error message")
logging.critical("hey this is critical message")

