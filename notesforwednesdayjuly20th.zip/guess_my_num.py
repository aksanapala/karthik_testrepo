#!/usr/bin/python
# break : a keyword to take you out of the loop.
# sys.exit: will take me out of the program.

import sys

answer =  raw_input("do you want to play the game- y/n :")
if answer == 'n':
  sys.exit()



number = 7
#test = True

while True:
  guess_num = int(raw_input("please enter a number:"))
  if guess_num > number:
    print "buddy!! you guessed a sligtly larger number"
  elif guess_num < number:
    print "buddy!! you guessed a sligtly smaller number"
  elif guess_num == number:
    print "Congo!! you guessed the right number"
    break
    #test = False
    
print "Thanks for playing the game"

# task
# i want the program should give maximum 3 chances.
