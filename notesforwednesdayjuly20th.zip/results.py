#!/usr/bin/python
# continue: for skipping your iteration.

for student in ('bharani','nayak','kumar','sangeeta','soundarya','padma'):
  if student == 'kumar':
    continue
    #break
    #pass
  print "report card for {}".format(student)
